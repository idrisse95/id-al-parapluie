$(function () {
  var $mainMenuItems = $("#main-menu ul").children("li"),
    totalMainMenuItems = $mainMenuItems.length,
    openedIndex = 2,
    init = function () {
      bindEvents();
      if (valIndex(openedIndex)) {
        animateItem($mainMenuItems.eq(openedIndex), true, 250);
      }
    },
    bindEvents = function () {
      $mainMenuItems.children(".images").click(function () {
        var newIndex = $(this).parent().index();
        checkAndAnimateItem(newIndex);
        $item = $mainMenuItems.eq(newIndex);
        if (openedIndex === newIndex) {
          animateItem($item, toOpen, 250);
          openedIndex = -1;
        } else {
          if (valIndex(newIndex)) {
            animateItem($mainMenuItems.eq(openedIndex), false, 250);
            openedIndex = newIndex;
            animateItem($item, true, 250);
          }
        }
      });

      $(".button").click(function () {
        var newIndex = $(this).index();
        $item = $mainMenuItems.eq(newIndex);
        if (openedIndex === newIndex) {
          animateItem($item, toOpen, 250);
          openedIndex = -1;
        } else {
          if (valIndex(newIndex)) {
            animateItem($mainMenuItems.eq(openedIndex), false, 250);
            openedIndex = newIndex;
            animateItem($item, true, 250);
          }
        }
      });
    },
    valIndex = function (indexToChek) {
      return indexToChek >= 0 && indexToChek < totalMainMenuItems;
    },
    animateItem = function ($item, toOpen, speed) {
      var $colorImage = $item.find(".color"),
        itemParam = toOpen ? { width: "420px" } : { width: "140px" },
        // Expression ? Valeur1: Valeur2
        colorImageParam = toOpen ? { left: "0px" } : { left: "140px" };
      $colorImage.animate({ left: "0px" }, 250);
      $item.animate(itemParam, speed);
    };

  checkAndAnimateItem = function (indexToCheckAndAnimate) {
    if (openedIndex === indexToCheckAndAnimate) {
      animateItem($mainMenuItems.eq(indexToCheckAndAnimate), false, 250);
      openedIndex = -1;
    } else {
      if (valIndex(newIndex)) {
        animateItem($mainMenuItems.eq(openedIndex), false, 250);
        openedIndex = indexToCheckAndAnimate;
        animateItem($mainMenuItems.eq(openedIndex), true, 250);
      }
    }
  };
  init();
});
